from .model import FHNModel
