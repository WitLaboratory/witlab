from .model import ThalamicMassModel
